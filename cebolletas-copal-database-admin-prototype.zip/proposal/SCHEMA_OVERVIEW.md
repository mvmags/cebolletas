# Schema overview

| Table | Purpose | Contains personal data |
|---|---|---:|
| `inventory_units` | Bookable units such as Copal or future camping capacity | No |
| `inquiry_topics` | Controlled list of information options | No |
| `booking_requests` | Visitor, dates, party size, question and current status | Yes |
| `booking_request_topics` | Topics selected for each request | Indirectly |
| `admin_profiles` | Allowlist and role for authenticated administrators | Yes |
| `booking_status_history` | Immutable status audit trail | Indirectly |

## Relationships

```mermaid
erDiagram
  INVENTORY_UNITS ||--o{ BOOKING_REQUESTS : receives
  BOOKING_REQUESTS ||--|{ BOOKING_REQUEST_TOPICS : requests
  INQUIRY_TOPICS ||--o{ BOOKING_REQUEST_TOPICS : classifies
  BOOKING_REQUESTS ||--|{ BOOKING_STATUS_HISTORY : records
  ADMIN_PROFILES ||--o{ BOOKING_STATUS_HISTORY : changes
```

## Status transitions

The application may use these normal transitions:

```mermaid
stateDiagram-v2
  [*] --> interested
  interested --> booked
  interested --> cancelled
  booked --> cancelled
  cancelled --> interested
  cancelled --> archived
  interested --> archived
```

The database records every change. The admin interface should require a
confirmation before moving a `booked` request to `cancelled` or `archived`.

