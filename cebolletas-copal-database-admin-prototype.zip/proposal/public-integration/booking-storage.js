/**
 * Isolated Version 5 integration adapter.
 *
 * The existing Reserva logic should call storeBookingRequest(payload) only
 * after its current client-side validation succeeds. The existing WhatsApp and
 * email flow remains in reserva-actions.js.
 *
 * Do not place a Supabase service-role key in this file.
 */

const BOOKING_SUBMISSION_ENDPOINT =
  "https://REPLACE-PROJECT-REF.supabase.co/functions/v1/submit-booking";

export async function storeBookingRequest(validatedForm, turnstileToken) {
  const payload = {
    name: validatedForm.name,
    email: validatedForm.email,
    cellphone: validatedForm.cellphone,
    checkIn: validatedForm.checkIn,
    checkOut: validatedForm.checkOut,
    adults: validatedForm.adults,
    children: validatedForm.children,
    topics: validatedForm.topics,
    otherRequest: validatedForm.otherRequest || "",
    turnstileToken,
  };

  const response = await fetch(BOOKING_SUBMISSION_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
    credentials: "omit",
    referrerPolicy: "strict-origin-when-cross-origin",
  });

  const result = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(result.error || "booking_storage_failed");
  }

  return {
    accepted: result.accepted === true,
    reference: String(result.reference || ""),
  };
}

