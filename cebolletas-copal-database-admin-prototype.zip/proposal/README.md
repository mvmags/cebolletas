# Review package

This package proposes the database, security policies, public submission
boundary and administrator experience for Cebolletas Copal.

## What is implemented

- Interactive administrator prototype with simulated records.
- Login-screen behavior for review only.
- Calendar with `interested`, `booked` and `cancelled` states.
- Search, status filter, record detail and simulated status changes.
- PostgreSQL schema and overlap rule.
- Supabase RLS policies and administrator allowlist.
- Server-side submission Edge Function.
- Isolated Version 5 storage adapter.
- Security test plan.

## Prototype login

- Email: `admin@cebolletas.mx`
- Password: `Demo-copal-2026`

These credentials are intentionally fake and are not a production security
mechanism.

## Review decisions requested

1. Is the two-role model (`admin`, `viewer`) enough?
2. Should the maximum stay remain 30 nights?
3. Should `camping` share the same inventory calendar as Copal or become a
   separate inventory unit?
4. Should cancelling a booking require a reason?
5. Should an administrator be able to edit visitor data, or only status?

