# Security and data-rule test plan

Run these tests in a non-production Supabase project before connecting Version 5.

## Authentication and RLS

| Test identity | Read bookings | Change status | Insert directly |
|---|---:|---:|---:|
| Anonymous | Denied | Denied | Denied |
| Authenticated, not allowlisted | Denied | Denied | Denied |
| Active viewer | Allowed | Denied | Denied |
| Inactive administrator | Denied | Denied | Denied |
| Active administrator | Allowed | Allowed | Denied |

## Submission endpoint

Verify a `403`, `413`, `422` or equivalent rejection for:

- origin other than `cebolletas.mx` or `www.cebolletas.mx`;
- missing or invalid Turnstile token;
- non-JSON request;
- body larger than 12 KB;
- name with fewer than five letters;
- malformed email or phone outside 10–15 digits;
- checkout on or before check-in;
- stay longer than 30 nights;
- adults outside 1–20 or children outside 0–20;
- empty topics or an unknown topic;
- `other` topic with fewer than ten characters of detail.

## Calendar integrity

1. Insert two overlapping `interested` requests: both must succeed.
2. Confirm the first request: it must succeed.
3. Confirm the overlapping request: it must fail with an exclusion violation.
4. Cancel the first request, then confirm the second: it must succeed.
5. Confirm adjacent stays where one checkout equals the next check-in: both must
   succeed.
6. Verify that every status transition appears in the history table with the
   administrator's user ID.

