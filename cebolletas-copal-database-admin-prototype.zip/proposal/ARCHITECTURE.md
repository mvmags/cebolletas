# Cebolletas Copal — database and administrator proposal

## Decision

Use Supabase for PostgreSQL, administrator email/password authentication, Row
Level Security and a public Edge Function. Keep Version 5 static and unchanged.

This prototype uses simulated records. It does not connect to a real Supabase
project and must not be uploaded as the production administrator application
until the credentials, security tests and deployment configuration are ready.

## Components

| Component | Responsibility | Reads private visitor data |
|---|---|---|
| Existing Version 5 | Form validation, WhatsApp and email flow | No |
| `booking-storage.js` | Calls the submission endpoint after existing validation | No |
| `submit-booking` Edge Function | Turnstile, server validation, atomic database write | Write only |
| Supabase PostgreSQL | Canonical visitor, request, dates and status data | Yes |
| `/copal/admin/` | Authenticated calendar, records and status updates | Yes |
| Supabase Auth + RLS | Identity and authorization enforcement | Yes |

## Request flow

1. Visitor completes the existing Version 5 Reserva form.
2. Existing client validation passes.
3. Turnstile supplies a one-time verification token.
4. The isolated storage adapter calls the Edge Function.
5. The Edge Function verifies origin, size, Turnstile and every input.
6. A server-only service-role key calls the atomic database function.
7. The record is saved as `interested`.
8. The existing email and WhatsApp drafts continue independently.

The database write should happen before the drafts are opened. If storage fails,
the page must show an error and must not claim that the request was recorded.

## Calendar rules

- A stay-night begins on check-in and ends before checkout: `[check_in, check_out)`.
- Friday and Saturday are weekend nights in the existing Version 5 calculation.
- `interested` requests may overlap.
- `booked` requests cannot overlap another `booked` request for the same
  inventory unit.
- `cancelled` and `archived` records remain in history but are hidden by default.
- Number of nights is derived from the two dates; it is not stored.

## Administrator roles

- `viewer`: sign in and read the calendar, visitors and status history.
- `admin`: all viewer permissions plus change request status.

There is no public registration. Administrators are created manually in
Supabase Auth and then allowlisted in `admin_profiles`.

## Production admin source boundary

The production static files should live only under:

```text
copal/
└── admin/
    ├── index.html
    ├── admin.css
    ├── admin.js
    ├── admin-auth.js
    ├── admin-calendar.js
    ├── admin-records.js
    └── supabase-config.js
```

The Supabase URL and anon key may be present in `supabase-config.js`; they are
public identifiers. Security must never depend on hiding them. The service-role
key and Turnstile secret remain server-side only.

## Security acceptance criteria

1. An anonymous browser receives zero rows from every booking table.
2. An authenticated but non-allowlisted user receives zero rows.
3. A `viewer` can read but cannot modify a request.
4. An `admin` can change status but cannot edit identity or dates directly.
5. The browser cannot execute `create_booking_request_internal`.
6. Direct anonymous inserts are rejected.
7. The Edge Function rejects an unapproved origin, invalid Turnstile token,
   oversized body, unexpected topic, invalid phone, invalid date order and stays
   longer than 30 nights.
8. Two overlapping `booked` rows for `copal` cannot coexist.
9. Every status change is written to `booking_status_history`.
10. Logs do not contain names, emails, phone numbers or free-text questions.

## Deliberate limitations

- The prototype does not send confirmations; Version 5 still opens WhatsApp and
  email drafts.
- The first schema models one bookable inventory unit but supports adding more.
- Pricing, payments, deposits and availability quotes are outside this phase.
- The 30-night maximum is a proposed abuse/business limit and can be changed.

