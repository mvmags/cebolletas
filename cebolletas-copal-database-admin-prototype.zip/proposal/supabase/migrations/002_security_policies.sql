-- Security model:
-- - anon cannot read or write booking data.
-- - authenticated users still receive no access unless allowlisted in admin_profiles.
-- - public submissions use the Edge Function and its server-only service-role key.
-- - administrator registration is disabled in Supabase Auth settings.

create schema if not exists private;

create or replace function private.is_active_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.admin_profiles as profile
    where profile.user_id = auth.uid()
      and profile.active = true
      and profile.role in ('admin', 'viewer')
  );
$$;

create or replace function private.can_manage_bookings()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.admin_profiles as profile
    where profile.user_id = auth.uid()
      and profile.active = true
      and profile.role = 'admin'
  );
$$;

revoke all on schema private from public;
grant usage on schema private to authenticated;
grant execute on function private.is_active_admin() to authenticated;
grant execute on function private.can_manage_bookings() to authenticated;

alter table public.inventory_units enable row level security;
alter table public.inventory_units force row level security;
alter table public.inquiry_topics enable row level security;
alter table public.inquiry_topics force row level security;
alter table public.booking_requests enable row level security;
alter table public.booking_requests force row level security;
alter table public.booking_request_topics enable row level security;
alter table public.booking_request_topics force row level security;
alter table public.admin_profiles enable row level security;
alter table public.admin_profiles force row level security;
alter table public.booking_status_history enable row level security;
alter table public.booking_status_history force row level security;

revoke all on table public.inventory_units from anon, authenticated;
revoke all on table public.inquiry_topics from anon, authenticated;
revoke all on table public.booking_requests from anon, authenticated;
revoke all on table public.booking_request_topics from anon, authenticated;
revoke all on table public.admin_profiles from anon, authenticated;
revoke all on table public.booking_status_history from anon, authenticated;

grant select on table public.inventory_units to authenticated;
grant select on table public.inquiry_topics to authenticated;
grant select on table public.booking_requests to authenticated;
grant select on table public.booking_request_topics to authenticated;
grant select on table public.admin_profiles to authenticated;
grant select on table public.booking_status_history to authenticated;
grant update (status) on table public.booking_requests to authenticated;

create policy inventory_units_admin_read
on public.inventory_units
for select
to authenticated
using ((select private.is_active_admin()));

create policy inquiry_topics_admin_read
on public.inquiry_topics
for select
to authenticated
using ((select private.is_active_admin()));

create policy booking_requests_admin_read
on public.booking_requests
for select
to authenticated
using ((select private.is_active_admin()));

create policy booking_requests_admin_status_update
on public.booking_requests
for update
to authenticated
using ((select private.can_manage_bookings()))
with check ((select private.can_manage_bookings()));

create policy booking_request_topics_admin_read
on public.booking_request_topics
for select
to authenticated
using ((select private.is_active_admin()));

create policy admin_profiles_self_or_admin_read
on public.admin_profiles
for select
to authenticated
using (
  user_id = (select auth.uid())
  or (select private.can_manage_bookings())
);

create policy booking_status_history_admin_read
on public.booking_status_history
for select
to authenticated
using ((select private.is_active_admin()));

-- Never callable from the browser, including an authenticated administrator.
revoke all on function public.create_booking_request_internal(
  text, text, text, text, date, date, smallint, smallint, text, text[], text
) from public, anon, authenticated;

grant execute on function public.create_booking_request_internal(
  text, text, text, text, date, date, smallint, smallint, text, text[], text
) to service_role;

