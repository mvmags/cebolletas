-- Cebolletas Copal booking database
-- PostgreSQL / Supabase

create extension if not exists btree_gist with schema extensions;

create type public.booking_status as enum (
  'interested',
  'booked',
  'cancelled',
  'archived'
);

create type public.admin_role as enum (
  'admin',
  'viewer'
);

create table public.inventory_units (
  id uuid primary key default gen_random_uuid(),
  code text not null unique
    check (code ~ '^[a-z0-9_]{2,40}$'),
  name_es text not null
    check (char_length(name_es) between 2 and 100),
  name_en text not null
    check (char_length(name_en) between 2 and 100),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.inquiry_topics (
  code text primary key
    check (code ~ '^[a-z0-9_]{2,40}$'),
  label_es text not null
    check (char_length(label_es) between 2 and 120),
  label_en text not null
    check (char_length(label_en) between 2 and 120),
  active boolean not null default true,
  sort_order smallint not null default 0
);

create table public.booking_requests (
  id uuid primary key default gen_random_uuid(),
  reference_code text not null unique default (
    'COP-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8))
  ),
  inventory_unit_id uuid not null
    references public.inventory_units(id) on delete restrict,
  visitor_name text not null
    check (char_length(visitor_name) between 5 and 100),
  visitor_email text not null
    check (
      char_length(visitor_email) <= 254
      and visitor_email ~* '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$'
    ),
  visitor_cellphone text not null
    check (visitor_cellphone ~ '^\+[1-9][0-9]{9,14}$'),
  check_in date not null,
  check_out date not null,
  adults smallint not null default 1
    check (adults between 1 and 20),
  children smallint not null default 0
    check (children between 0 and 20),
  other_request text
    check (other_request is null or char_length(other_request) <= 1000),
  status public.booking_status not null default 'interested',
  source text not null default 'copal_web'
    check (char_length(source) between 2 and 40),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint booking_dates_valid check (check_out > check_in),
  constraint booking_length_reasonable check (check_out <= check_in + 30)
);

create table public.booking_request_topics (
  booking_request_id uuid not null
    references public.booking_requests(id) on delete cascade,
  topic_code text not null
    references public.inquiry_topics(code) on delete restrict,
  primary key (booking_request_id, topic_code)
);

create table public.admin_profiles (
  user_id uuid primary key
    references auth.users(id) on delete cascade,
  role public.admin_role not null default 'viewer',
  display_name text not null
    check (char_length(display_name) between 2 and 100),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.booking_status_history (
  id bigint generated always as identity primary key,
  booking_request_id uuid not null
    references public.booking_requests(id) on delete cascade,
  from_status public.booking_status,
  to_status public.booking_status not null,
  changed_by uuid references auth.users(id) on delete set null,
  changed_at timestamptz not null default now()
);

-- Only one confirmed booking may occupy an inventory unit on any stay-night.
-- Interested requests may overlap by design.
alter table public.booking_requests
  add constraint confirmed_bookings_do_not_overlap
  exclude using gist (
    inventory_unit_id with =,
    daterange(check_in, check_out, '[)') with &&
  )
  where (status = 'booked');

create index booking_requests_status_dates_idx
  on public.booking_requests (status, check_in, check_out);

create index booking_requests_created_at_idx
  on public.booking_requests (created_at desc);

create index booking_requests_email_idx
  on public.booking_requests (lower(visitor_email));

create index booking_status_history_request_idx
  on public.booking_status_history (booking_request_id, changed_at desc);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger booking_requests_set_updated_at
before update on public.booking_requests
for each row execute function public.set_updated_at();

create trigger admin_profiles_set_updated_at
before update on public.admin_profiles
for each row execute function public.set_updated_at();

create or replace function public.record_booking_status_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if tg_op = 'INSERT' then
    insert into public.booking_status_history (
      booking_request_id,
      from_status,
      to_status,
      changed_by
    ) values (
      new.id,
      null,
      new.status,
      auth.uid()
    );
  elsif old.status is distinct from new.status then
    insert into public.booking_status_history (
      booking_request_id,
      from_status,
      to_status,
      changed_by
    ) values (
      new.id,
      old.status,
      new.status,
      auth.uid()
    );
  end if;
  return new;
end;
$$;

create trigger booking_requests_record_status
after insert or update of status on public.booking_requests
for each row execute function public.record_booking_status_change();

-- Atomic insertion boundary used only by the server-side Edge Function.
create or replace function public.create_booking_request_internal(
  p_inventory_code text,
  p_visitor_name text,
  p_visitor_email text,
  p_visitor_cellphone text,
  p_check_in date,
  p_check_out date,
  p_adults smallint,
  p_children smallint,
  p_other_request text,
  p_topics text[],
  p_source text default 'copal_web'
)
returns table (id uuid, reference_code text)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_inventory_id uuid;
  v_request_id uuid;
  v_reference_code text;
begin
  select unit.id
    into v_inventory_id
  from public.inventory_units as unit
  where unit.code = p_inventory_code
    and unit.active = true;

  if v_inventory_id is null then
    raise exception 'inventory unit is unavailable';
  end if;

  if coalesce(array_length(p_topics, 1), 0) < 1 then
    raise exception 'at least one inquiry topic is required';
  end if;

  if exists (
    select 1
    from unnest(p_topics) as requested(code)
    left join public.inquiry_topics as topic
      on topic.code = requested.code
      and topic.active = true
    where topic.code is null
  ) then
    raise exception 'invalid inquiry topic';
  end if;

  insert into public.booking_requests (
    inventory_unit_id,
    visitor_name,
    visitor_email,
    visitor_cellphone,
    check_in,
    check_out,
    adults,
    children,
    other_request,
    source
  ) values (
    v_inventory_id,
    p_visitor_name,
    lower(p_visitor_email),
    p_visitor_cellphone,
    p_check_in,
    p_check_out,
    p_adults,
    p_children,
    nullif(p_other_request, ''),
    p_source
  )
  returning booking_requests.id, booking_requests.reference_code
    into v_request_id, v_reference_code;

  insert into public.booking_request_topics (
    booking_request_id,
    topic_code
  )
  select v_request_id, requested.code
  from (
    select distinct unnest(p_topics) as code
  ) as requested;

  return query select v_request_id, v_reference_code;
end;
$$;

insert into public.inventory_units (code, name_es, name_en)
values ('copal', 'Cebolletas Copal', 'Cebolletas Copal')
on conflict (code) do nothing;

insert into public.inquiry_topics (code, label_es, label_en, sort_order)
values
  ('stay_copal', 'Hospedarse en Cebolletas Copal', 'Staying at Cebolletas Copal', 10),
  ('camping', 'Acampar', 'Camping', 20),
  ('other', 'Otro', 'Other', 30)
on conflict (code) do nothing;

