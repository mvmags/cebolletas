import { createClient } from "jsr:@supabase/supabase-js@2";

const ALLOWED_ORIGINS = new Set([
  "https://cebolletas.mx",
  "https://www.cebolletas.mx",
]);

const ALLOWED_TOPICS = new Set(["stay_copal", "camping", "other"]);
const MAX_BODY_BYTES = 12_000;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function corsHeaders(origin: string | null) {
  const allowedOrigin = origin && ALLOWED_ORIGINS.has(origin) ? origin : "";
  return {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Headers": "content-type, x-client-info",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin",
  };
}

function jsonResponse(
  body: Record<string, unknown>,
  status: number,
  origin: string | null,
) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      ...corsHeaders(origin),
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
    },
  });
}

function normalizeSingleLine(value: unknown, maxLength: number) {
  return String(value ?? "")
    .normalize("NFKC")
    .replace(/[\u0000-\u001F\u007F]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, maxLength);
}

function normalizeMultiline(value: unknown, maxLength: number) {
  return String(value ?? "")
    .normalize("NFKC")
    .replace(/\r\n?/g, "\n")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "")
    .trim()
    .slice(0, maxLength);
}

function normalizePhone(value: unknown) {
  const digits = String(value ?? "").replace(/\D/g, "");
  if (digits.length < 10 || digits.length > 15 || digits.startsWith("0")) {
    return null;
  }
  return `+${digits}`;
}

function parseDate(value: unknown) {
  const text = String(value ?? "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return null;
  const date = new Date(`${text}T00:00:00Z`);
  return Number.isNaN(date.getTime()) ||
      date.toISOString().slice(0, 10) !== text
    ? null
    : text;
}

function integerInRange(value: unknown, min: number, max: number) {
  return Number.isInteger(value) && Number(value) >= min && Number(value) <= max
    ? Number(value)
    : null;
}

async function verifyTurnstile(token: string, remoteIp: string | null) {
  const secret = Deno.env.get("TURNSTILE_SECRET_KEY");
  if (!secret || !token) return false;

  const formData = new FormData();
  formData.set("secret", secret);
  formData.set("response", token);
  if (remoteIp) formData.set("remoteip", remoteIp);

  const response = await fetch(
    "https://challenges.cloudflare.com/turnstile/v0/siteverify",
    { method: "POST", body: formData },
  );
  if (!response.ok) return false;
  const result = await response.json();
  return result.success === true;
}

Deno.serve(async (request) => {
  const origin = request.headers.get("origin");

  if (!origin || !ALLOWED_ORIGINS.has(origin)) {
    return jsonResponse({ error: "origin_not_allowed" }, 403, origin);
  }

  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders(origin) });
  }

  if (request.method !== "POST") {
    return jsonResponse({ error: "method_not_allowed" }, 405, origin);
  }

  const contentType = request.headers.get("content-type") ?? "";
  const declaredSize = Number(request.headers.get("content-length") ?? "0");
  if (
    !contentType.toLowerCase().startsWith("application/json") ||
    declaredSize > MAX_BODY_BYTES
  ) {
    return jsonResponse({ error: "invalid_request" }, 400, origin);
  }

  const rawBody = await request.text();
  if (new TextEncoder().encode(rawBody).byteLength > MAX_BODY_BYTES) {
    return jsonResponse({ error: "payload_too_large" }, 413, origin);
  }

  let body: Record<string, unknown>;
  try {
    body = JSON.parse(rawBody);
  } catch {
    return jsonResponse({ error: "invalid_json" }, 400, origin);
  }

  const turnstileToken = normalizeSingleLine(body.turnstileToken, 2048);
  const turnstileValid = await verifyTurnstile(
    turnstileToken,
    request.headers.get("cf-connecting-ip"),
  );
  if (!turnstileValid) {
    return jsonResponse({ error: "verification_failed" }, 400, origin);
  }

  const name = normalizeSingleLine(body.name, 100);
  const email = normalizeSingleLine(body.email, 254).toLowerCase();
  const cellphone = normalizePhone(body.cellphone);
  const checkIn = parseDate(body.checkIn);
  const checkOut = parseDate(body.checkOut);
  const adults = integerInRange(body.adults, 1, 20);
  const children = integerInRange(body.children, 0, 20);
  const otherRequest = normalizeMultiline(body.otherRequest, 1000);
  const topics = Array.isArray(body.topics)
    ? [...new Set(body.topics.map((item) => normalizeSingleLine(item, 40)))]
    : [];

  const errors: string[] = [];
  const letterCount = (name.match(/\p{L}/gu) ?? []).length;
  if (letterCount < 5) errors.push("name");
  if (!EMAIL_PATTERN.test(email)) errors.push("email");
  if (!cellphone) errors.push("cellphone");
  if (!checkIn || !checkOut || checkOut <= checkIn) errors.push("dates");
  if (
    checkIn &&
    checkOut &&
    (new Date(`${checkOut}T00:00:00Z`).getTime() -
        new Date(`${checkIn}T00:00:00Z`).getTime()) /
        86_400_000 >
      30
  ) {
    errors.push("stay_length");
  }
  if (adults === null) errors.push("adults");
  if (children === null) errors.push("children");
  if (!topics.length || topics.some((topic) => !ALLOWED_TOPICS.has(topic))) {
    errors.push("topics");
  }
  if (topics.includes("other") && otherRequest.length < 10) {
    errors.push("other_request");
  }

  if (errors.length) {
    return jsonResponse({ error: "validation_failed", fields: errors }, 422, origin);
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !serviceRoleKey) {
    console.error("Missing server configuration");
    return jsonResponse({ error: "service_unavailable" }, 503, origin);
  }

  const supabase = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data, error } = await supabase.rpc(
    "create_booking_request_internal",
    {
      p_inventory_code: "copal",
      p_visitor_name: name,
      p_visitor_email: email,
      p_visitor_cellphone: cellphone,
      p_check_in: checkIn,
      p_check_out: checkOut,
      p_adults: adults,
      p_children: children,
      p_other_request: otherRequest,
      p_topics: topics,
      p_source: "copal_web",
    },
  );

  if (error || !data?.[0]) {
    console.error("Submission failed", error?.code);
    return jsonResponse({ error: "submission_failed" }, 500, origin);
  }

  return jsonResponse(
    {
      accepted: true,
      reference: data[0].reference_code,
    },
    201,
    origin,
  );
});

