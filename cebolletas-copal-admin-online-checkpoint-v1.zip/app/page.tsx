"use client";

// Isolated online review checkpoint; Version 5 remains unchanged.

import { FormEvent, useMemo, useState } from "react";

type Status = "interested" | "booked" | "cancelled";

type RequestRecord = {
  id: string;
  guest: string;
  email: string;
  phone: string;
  checkIn: string;
  checkOut: string;
  adults: number;
  children: number;
  topics: string[];
  notes?: string;
  status: Status;
  createdAt: string;
};

const INITIAL_REQUESTS: RequestRecord[] = [
  {
    id: "COP-1048",
    guest: "Andrea López",
    email: "andrea.lopez@example.com",
    phone: "+52 449 555 0198",
    checkIn: "2026-08-01",
    checkOut: "2026-08-04",
    adults: 2,
    children: 1,
    topics: ["Hospedarse en Cebolletas Copal"],
    notes: "¿La cocina incluye cafetera?",
    status: "booked",
    createdAt: "28 jul 2026 · 18:42",
  },
  {
    id: "COP-1047",
    guest: "Rodrigo Méndez",
    email: "rodrigo.m@example.com",
    phone: "+52 449 555 0271",
    checkIn: "2026-08-07",
    checkOut: "2026-08-10",
    adults: 4,
    children: 0,
    topics: ["Hospedarse en Cebolletas Copal", "Acampar"],
    status: "interested",
    createdAt: "28 jul 2026 · 16:15",
  },
  {
    id: "COP-1046",
    guest: "Lucía Torres",
    email: "lucia.t@example.com",
    phone: "+52 449 555 0142",
    checkIn: "2026-08-15",
    checkOut: "2026-08-17",
    adults: 2,
    children: 2,
    topics: ["Hospedarse en Cebolletas Copal"],
    status: "booked",
    createdAt: "27 jul 2026 · 21:08",
  },
  {
    id: "COP-1045",
    guest: "Manuel Ríos",
    email: "manuel.rios@example.com",
    phone: "+52 449 555 0335",
    checkIn: "2026-08-15",
    checkOut: "2026-08-18",
    adults: 3,
    children: 1,
    topics: ["Acampar", "Otro"],
    notes: "Información para llevar dos bicicletas.",
    status: "interested",
    createdAt: "27 jul 2026 · 13:52",
  },
  {
    id: "COP-1044",
    guest: "Elena Ortiz",
    email: "elena.o@example.com",
    phone: "+52 449 555 0418",
    checkIn: "2026-08-22",
    checkOut: "2026-08-24",
    adults: 2,
    children: 0,
    topics: ["Hospedarse en Cebolletas Copal"],
    status: "interested",
    createdAt: "26 jul 2026 · 19:06",
  },
];

const STATUS_LABEL: Record<Status, string> = {
  interested: "Interesado",
  booked: "Reservado",
  cancelled: "Cancelado",
};

const MONTH_NAME = "Agosto 2026";
const DAY_HEADERS = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"];

function localDate(value: string) {
  return new Date(`${value}T12:00:00`);
}

function formatShortDate(value: string) {
  return new Intl.DateTimeFormat("es-MX", {
    day: "numeric",
    month: "short",
  }).format(localDate(value));
}

function nightsBetween(start: string, end: string) {
  return Math.round(
    (localDate(end).getTime() - localDate(start).getTime()) / 86_400_000,
  );
}

function coversDay(record: RequestRecord, day: number) {
  const current = new Date(2026, 7, day, 12);
  return current >= localDate(record.checkIn) && current < localDate(record.checkOut);
}

function LogoMark() {
  return (
    <div className="logo-mark" aria-hidden="true">
      <span className="logo-branch branch-a" />
      <span className="logo-branch branch-b" />
      <span className="logo-branch branch-c" />
      <span className="logo-trunk" />
      <span className="logo-ground" />
    </div>
  );
}

export default function Home() {
  const [authenticated, setAuthenticated] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [requests, setRequests] = useState(INITIAL_REQUESTS);
  const [activeFilter, setActiveFilter] = useState<"all" | Status>("all");
  const [selectedId, setSelectedId] = useState("COP-1048");
  const [query, setQuery] = useState("");
  const [statusNotice, setStatusNotice] = useState("");

  const selected =
    requests.find((request) => request.id === selectedId) ?? requests[0];

  const visibleRequests = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase("es-MX");
    return requests.filter((request) => {
      const matchesStatus =
        activeFilter === "all" || request.status === activeFilter;
      const matchesSearch =
        !normalized ||
        `${request.guest} ${request.email} ${request.id}`
          .toLocaleLowerCase("es-MX")
          .includes(normalized);
      return matchesStatus && matchesSearch;
    });
  }, [requests, activeFilter, query]);

  const calendarDays = useMemo(() => {
    const days: Array<number | null> = [null, null, null, null, null];
    for (let day = 1; day <= 31; day += 1) days.push(day);
    while (days.length % 7 !== 0) days.push(null);
    return days;
  }, []);

  function handleLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const email = String(data.get("email") ?? "").trim();
    const password = String(data.get("password") ?? "");

    if (email === "admin@cebolletas.mx" && password === "Demo-copal-2026") {
      setLoginError("");
      setAuthenticated(true);
      return;
    }
    setLoginError("Usa las credenciales de demostración indicadas abajo.");
  }

  function updateSelectedStatus(status: Status) {
    if (status === "booked") {
      const conflictingBooking = requests.find(
        (request) =>
          request.id !== selected.id &&
          request.status === "booked" &&
          localDate(request.checkIn) < localDate(selected.checkOut) &&
          localDate(request.checkOut) > localDate(selected.checkIn),
      );

      if (conflictingBooking) {
        setStatusNotice(
          `No se puede confirmar: coincide con ${conflictingBooking.id}, ${conflictingBooking.guest}.`,
        );
        return;
      }
    }

    setRequests((current) =>
      current.map((request) =>
        request.id === selected.id ? { ...request, status } : request,
      ),
    );
    setStatusNotice(`Estado actualizado a “${STATUS_LABEL[status]}”.`);
  }

  if (!authenticated) {
    return (
      <main className="login-shell">
        <section className="login-brand">
          <div className="brand-lockup">
            <LogoMark />
            <div>
              <p className="eyebrow light">Cebolletas</p>
              <h1>Copal</h1>
            </div>
          </div>
          <div className="login-brand-copy">
            <span className="prototype-pill">Prototipo aislado</span>
            <h2>Las reservaciones, claras de un vistazo.</h2>
            <p>
              Consulta solicitudes, confirma estadías y detecta traslapes en un
              solo calendario.
            </p>
          </div>
          <p className="brand-footer">Calvillo, Aguascalientes</p>
        </section>

        <section className="login-panel">
          <form className="login-card" onSubmit={handleLogin} noValidate>
            <p className="eyebrow">Acceso administrativo</p>
            <h2>Bienvenido</h2>
            <p className="muted">
              Ingresa con una cuenta autorizada para consultar información de
              visitantes.
            </p>

            <label htmlFor="email">Correo electrónico</label>
            <input
              id="email"
              name="email"
              type="email"
              defaultValue="admin@cebolletas.mx"
              autoComplete="username"
              required
            />

            <label htmlFor="password">Contraseña</label>
            <input
              id="password"
              name="password"
              type="password"
              defaultValue="Demo-copal-2026"
              autoComplete="current-password"
              required
            />

            {loginError && (
              <p className="login-error" role="alert">
                {loginError}
              </p>
            )}

            <button className="primary-button" type="submit">
              Entrar al prototipo
            </button>

            <div className="demo-note">
              <strong>Acceso de demostración</strong>
              <span>admin@cebolletas.mx</span>
              <span>Demo-copal-2026</span>
            </div>
            <p className="security-note">
              En producción, estas credenciales no existirán en el código. El
              acceso será validado por Supabase Auth y las políticas RLS.
            </p>
          </form>
        </section>
      </main>
    );
  }

  return (
    <main className="admin-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <LogoMark />
          <div>
            <p>Cebolletas</p>
            <strong>Copal</strong>
          </div>
        </div>

        <nav aria-label="Navegación administrativa">
          <button className="nav-item active" type="button">
            <span className="nav-dot" />
            Calendario
          </button>
          <button className="nav-item" type="button">
            <span className="nav-dot" />
            Solicitudes
            <b>{requests.filter((item) => item.status === "interested").length}</b>
          </button>
          <button className="nav-item" type="button">
            <span className="nav-dot" />
            Reservaciones
          </button>
        </nav>

        <div className="sidebar-bottom">
          <div className="admin-avatar">MV</div>
          <div>
            <strong>Marco</strong>
            <span>Administrador</span>
          </div>
          <button
            className="logout-button"
            type="button"
            onClick={() => setAuthenticated(false)}
            aria-label="Cerrar sesión"
          >
            Salir
          </button>
        </div>
      </aside>

      <section className="dashboard">
        <header className="dashboard-header">
          <div>
            <p className="eyebrow">Administración de reservas</p>
            <h1>Calendario</h1>
          </div>
          <div className="header-actions">
            <span className="prototype-pill warm">Datos simulados</span>
            <button className="secondary-button" type="button">
              Exportar
            </button>
          </div>
        </header>

        <section className="stats-grid" aria-label="Resumen">
          <article>
            <span className="stat-accent green" />
            <p>Reservaciones confirmadas</p>
            <strong>{requests.filter((item) => item.status === "booked").length}</strong>
            <small>Agosto 2026</small>
          </article>
          <article>
            <span className="stat-accent amber" />
            <p>Solicitudes interesadas</p>
            <strong>
              {requests.filter((item) => item.status === "interested").length}
            </strong>
            <small>Requieren seguimiento</small>
          </article>
          <article>
            <span className="stat-accent ink" />
            <p>Visitantes previstos</p>
            <strong>
              {requests
                .filter((item) => item.status === "booked")
                .reduce((sum, item) => sum + item.adults + item.children, 0)}
            </strong>
            <small>Adultos y niños</small>
          </article>
        </section>

        <div className="workspace-grid">
          <section className="calendar-card">
            <div className="calendar-toolbar">
              <div>
                <button type="button" aria-label="Mes anterior">
                  ‹
                </button>
                <button type="button" aria-label="Mes siguiente">
                  ›
                </button>
                <h2>{MONTH_NAME}</h2>
              </div>
              <div className="legend">
                <span><i className="booked" /> Reservado</span>
                <span><i className="interested" /> Interesado</span>
              </div>
            </div>

            <div className="calendar" role="grid" aria-label={MONTH_NAME}>
              {DAY_HEADERS.map((day) => (
                <div className="weekday" key={day} role="columnheader">
                  {day}
                </div>
              ))}
              {calendarDays.map((day, index) => {
                const dayRequests = day
                  ? requests.filter(
                      (request) =>
                        request.status !== "cancelled" &&
                        coversDay(request, day),
                    )
                  : [];
                return (
                  <div
                    className={`calendar-day ${day ? "" : "empty"}`}
                    key={`${day ?? "empty"}-${index}`}
                    role="gridcell"
                  >
                    {day && <span className="day-number">{day}</span>}
                    <div className="day-events">
                      {dayRequests.slice(0, 2).map((request) => (
                        <button
                          className={`calendar-event ${request.status} ${
                            selected.id === request.id ? "selected" : ""
                          }`}
                          key={request.id}
                          type="button"
                          onClick={() => {
                            setSelectedId(request.id);
                            setStatusNotice("");
                          }}
                          title={`${request.guest}: ${STATUS_LABEL[request.status]}`}
                        >
                          {request.guest.split(" ")[0]}
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          <aside className="detail-card" aria-live="polite">
            <div className="detail-heading">
              <div>
                <span className={`status-badge ${selected.status}`}>
                  {STATUS_LABEL[selected.status]}
                </span>
                <p>{selected.id}</p>
              </div>
              <button type="button" aria-label="Más opciones">
                ···
              </button>
            </div>
            <h2>{selected.guest}</h2>
            <p className="detail-created">Recibida {selected.createdAt}</p>

            <div className="stay-summary">
              <div>
                <span>Llegada</span>
                <strong>{formatShortDate(selected.checkIn)}</strong>
              </div>
              <div className="nights">
                <span>{nightsBetween(selected.checkIn, selected.checkOut)}</span>
                <small>noches</small>
              </div>
              <div>
                <span>Salida</span>
                <strong>{formatShortDate(selected.checkOut)}</strong>
              </div>
            </div>

            <dl className="detail-list">
              <div>
                <dt>Huéspedes</dt>
                <dd>
                  {selected.adults} adultos · {selected.children} niños
                </dd>
              </div>
              <div>
                <dt>Correo</dt>
                <dd>{selected.email}</dd>
              </div>
              <div>
                <dt>Celular</dt>
                <dd>{selected.phone}</dd>
              </div>
              <div>
                <dt>Información solicitada</dt>
                <dd>{selected.topics.join(" · ")}</dd>
              </div>
              {selected.notes && (
                <div>
                  <dt>Pregunta</dt>
                  <dd>{selected.notes}</dd>
                </div>
              )}
            </dl>

            <div className="status-actions">
              <p>Cambiar estado</p>
              <div>
                <button
                  className={selected.status === "interested" ? "active" : ""}
                  type="button"
                  onClick={() => updateSelectedStatus("interested")}
                >
                  Interesado
                </button>
                <button
                  className={selected.status === "booked" ? "active booked" : ""}
                  type="button"
                  onClick={() => updateSelectedStatus("booked")}
                >
                  Reservado
                </button>
                <button
                  className={selected.status === "cancelled" ? "active danger" : ""}
                  type="button"
                  onClick={() => updateSelectedStatus("cancelled")}
                >
                  Cancelado
                </button>
              </div>
              {statusNotice && (
                <p
                  className={`status-notice ${
                    statusNotice.startsWith("No se puede") ? "error" : ""
                  }`}
                  role="status"
                >
                  {statusNotice}
                </p>
              )}
            </div>
          </aside>
        </div>

        <section className="requests-card">
          <div className="requests-header">
            <div>
              <p className="eyebrow">Seguimiento</p>
              <h2>Solicitudes recientes</h2>
            </div>
            <div className="request-controls">
              <input
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Buscar visitante…"
                aria-label="Buscar visitante"
              />
              <select
                value={activeFilter}
                onChange={(event) =>
                  setActiveFilter(event.target.value as "all" | Status)
                }
                aria-label="Filtrar por estado"
              >
                <option value="all">Todos los estados</option>
                <option value="interested">Interesado</option>
                <option value="booked">Reservado</option>
                <option value="cancelled">Cancelado</option>
              </select>
            </div>
          </div>

          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Visitante</th>
                  <th>Estadía</th>
                  <th>Huéspedes</th>
                  <th>Estado</th>
                  <th>Solicitud</th>
                </tr>
              </thead>
              <tbody>
                {visibleRequests.map((request) => (
                  <tr
                    className={selected.id === request.id ? "current" : ""}
                    key={request.id}
                    onClick={() => {
                      setSelectedId(request.id);
                      setStatusNotice("");
                    }}
                  >
                    <td>
                      <strong>{request.guest}</strong>
                      <span>{request.email}</span>
                    </td>
                    <td>
                      {formatShortDate(request.checkIn)} –{" "}
                      {formatShortDate(request.checkOut)}
                    </td>
                    <td>{request.adults + request.children}</td>
                    <td>
                      <span className={`status-badge ${request.status}`}>
                        {STATUS_LABEL[request.status]}
                      </span>
                    </td>
                    <td>{request.id}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!visibleRequests.length && (
              <p className="empty-state">No hay solicitudes con estos filtros.</p>
            )}
          </div>
        </section>
      </section>
    </main>
  );
}
