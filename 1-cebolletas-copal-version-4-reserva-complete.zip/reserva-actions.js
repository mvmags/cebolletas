// Reserva validation and delivery actions.
// Intentionally independent from the Version 4 navigation code.
(function initReservaActions() {
  "use strict";

  const RESERVA_CONTACT = Object.freeze({
    whatsapp: "524491028878",
    email: "cebolletascalvillo@gmail.com",
    emailCc: "elcrio88@gmail.com"
  });

  const limits = Object.freeze({
    adults: 20,
    kids: 20,
    name: 100,
    email: 254,
    cell: 25,
    otherDetails: 1000,
    message: 1000
  });

  const messages = {
    es: {
      requiredCheckin: "La fecha de llegada es requerida.",
      pastCheckin: "La fecha de llegada no puede estar en el pasado.",
      requiredCheckout: "La fecha de salida es requerida.",
      invalidCheckout: "La fecha de salida debe ser posterior a la fecha de llegada.",
      invalidAdults: "Adultos debe ser un número entero entre 1 y 20.",
      invalidKids: "Niños debe ser un número entero entre 0 y 20.",
      requiredName: "El nombre es requerido.",
      shortName: "El nombre debe contener al menos 5 letras.",
      invalidName: "Usa únicamente letras, espacios, apóstrofes, puntos o guiones.",
      longName: "El nombre es demasiado largo (máximo 100 caracteres).",
      requiredEmail: "El email es requerido.",
      invalidEmail: "El formato del email no es válido.",
      requiredCell: "El celular es requerido.",
      invalidCell: "Ingresa un celular válido de 10 a 15 dígitos.",
      requiredInfo: "Selecciona al menos una opción.",
      requiredOther: "Describe qué otra información necesitas.",
      longOther: "El texto es demasiado largo (máximo 1000 caracteres).",
      requiredMessage: "El mensaje es requerido.",
      shortMessage: "El mensaje debe tener al menos 10 caracteres.",
      longMessage: "El mensaje es demasiado largo (máximo 1000 caracteres).",
      openingWhatsApp: "Abriendo WhatsApp…",
      openingEmail: "Abriendo email…",
      infoSubject: "Solicitud de información",
      messageSubject: "Mensaje",
      yes: "Sí",
      no: "No",
      labels: {
        checkin: "Fecha llegada",
        checkout: "Fecha salida",
        adults: "Adultos",
        kids: "Niños",
        name: "Nombre",
        email: "Email",
        cell: "Celular",
        requestedInfo: "Información solicitada",
        otherDetails: "Otra información",
        whatsappPreference: "Contacto por WhatsApp",
        type: "Tipo",
        message: "Mensaje",
        infoType: "Envíame información",
        messageType: "Enviar mensaje"
      },
      infoOptions: {
        copal: "Hospedarse en Cebolletas Copal",
        camping: "Acampar",
        other: "Otro"
      }
    },
    en: {
      requiredCheckin: "Check-in is required.",
      pastCheckin: "Check-in cannot be in the past.",
      requiredCheckout: "Checkout is required.",
      invalidCheckout: "Checkout must be later than check-in.",
      invalidAdults: "Adults must be a whole number between 1 and 20.",
      invalidKids: "Kids must be a whole number between 0 and 20.",
      requiredName: "Name is required.",
      shortName: "Name must contain at least 5 letters.",
      invalidName: "Use only letters, spaces, apostrophes, periods, or hyphens.",
      longName: "Name is too long (maximum 100 characters).",
      requiredEmail: "Email is required.",
      invalidEmail: "Email format is invalid.",
      requiredCell: "Cellphone is required.",
      invalidCell: "Enter a valid cellphone number containing 10 to 15 digits.",
      requiredInfo: "Select at least one option.",
      requiredOther: "Describe what other information you need.",
      longOther: "Text is too long (maximum 1000 characters).",
      requiredMessage: "Message is required.",
      shortMessage: "Message must contain at least 10 characters.",
      longMessage: "Message is too long (maximum 1000 characters).",
      openingWhatsApp: "Opening WhatsApp…",
      openingEmail: "Opening email…",
      infoSubject: "Information request",
      messageSubject: "Message",
      yes: "Yes",
      no: "No",
      labels: {
        checkin: "Check-in",
        checkout: "Checkout",
        adults: "Adults",
        kids: "Kids",
        name: "Name",
        email: "Email",
        cell: "Cellphone",
        requestedInfo: "Requested information",
        otherDetails: "Other information",
        whatsappPreference: "Contact by WhatsApp",
        type: "Type",
        message: "Message",
        infoType: "Send me information",
        messageType: "Send a message"
      },
      infoOptions: {
        copal: "Staying at Cebolletas Copal",
        camping: "Camping",
        other: "Other"
      }
    }
  };

  function getLanguage() {
    return document.documentElement.lang === "en" ? "en" : "es";
  }

  function getForm() {
    return document.getElementById("reserva-form");
  }

  function getLocalDate() {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  function sanitizeSingleLine(value) {
    return String(value)
      .normalize("NFKC")
      .replace(/[\u0000-\u001F\u007F]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function sanitizeMultiline(value) {
    return String(value)
      .normalize("NFKC")
      .replace(/\r\n?/g, "\n")
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "")
      .trim();
  }

  function getErrorHost(input) {
    if (!input) return null;
    if (input.matches("fieldset")) return input;
    return input.closest("label") || input;
  }

  function clearFieldError(input) {
    if (!input) return;
    const host = getErrorHost(input);
    host?.querySelector(":scope > .reserva-field-error")?.remove();
    input.removeAttribute("aria-invalid");
    if (input.matches("fieldset")) {
      input.querySelectorAll("[aria-invalid]").forEach((item) => {
        item.removeAttribute("aria-invalid");
      });
    }
  }

  function showFieldError(input, message) {
    if (!input) return;
    clearFieldError(input);
    const error = document.createElement("span");
    error.className = "reserva-field-error";
    error.textContent = message;
    const host = getErrorHost(input);
    host.appendChild(error);
    input.setAttribute("aria-invalid", "true");
  }

  function validate(form) {
    const text = messages[getLanguage()];
    const fields = {
      checkin: form.querySelector("#br-checkin"),
      checkout: form.querySelector("#br-checkout"),
      adults: form.querySelector("#br-adults"),
      kids: form.querySelector("#br-kids"),
      name: form.querySelector("#br-name"),
      email: form.querySelector("#br-email"),
      cell: form.querySelector("#br-cell"),
      info: form.querySelector(".info-options"),
      other: form.querySelector("#br-other"),
      otherDetails: form.querySelector("#br-other-details"),
      message: form.querySelector("#br-msg")
    };
    const requestType =
      form.querySelector('input[name="request-type"]:checked')?.value || "information";
    const selectedInfo = Array.from(
      form.querySelectorAll('input[name="requested-info"]:checked'),
      (input) => input.value
    );

    const data = {
      checkin: fields.checkin.value,
      checkout: fields.checkout.value,
      adults: Number(fields.adults.value),
      kids: Number(fields.kids.value),
      name: sanitizeSingleLine(fields.name.value),
      email: sanitizeSingleLine(fields.email.value),
      cell: sanitizeSingleLine(fields.cell.value),
      requestedInfo: selectedInfo,
      otherDetails: sanitizeMultiline(fields.otherDetails.value),
      whatsappPreference: form.querySelector("#br-whatsapp-preference").checked,
      message: sanitizeMultiline(fields.message.value),
      requestType
    };

    form.querySelectorAll(".reserva-field-error").forEach((element) => element.remove());
    form.querySelectorAll('[aria-invalid="true"]').forEach((element) => {
      element.removeAttribute("aria-invalid");
    });

    let firstInvalid = null;
    const reject = (field, message, focusTarget = field) => {
      showFieldError(field, message);
      firstInvalid ||= focusTarget;
    };
    const today = getLocalDate();

    if (!data.checkin) reject(fields.checkin, text.requiredCheckin);
    else if (data.checkin < today) reject(fields.checkin, text.pastCheckin);

    if (!data.checkout) reject(fields.checkout, text.requiredCheckout);
    else if (data.checkin && data.checkout <= data.checkin) {
      reject(fields.checkout, text.invalidCheckout);
    }

    if (!Number.isInteger(data.adults) || data.adults < 1 || data.adults > limits.adults) {
      reject(fields.adults, text.invalidAdults);
    }

    if (!Number.isInteger(data.kids) || data.kids < 0 || data.kids > limits.kids) {
      reject(fields.kids, text.invalidKids);
    }

    const letterCount = (data.name.match(/\p{L}/gu) || []).length;
    if (!data.name) reject(fields.name, text.requiredName);
    else if (letterCount < 5) reject(fields.name, text.shortName);
    else if (data.name.length > limits.name) reject(fields.name, text.longName);
    else if (!/^[\p{L}\p{M} .'\-]+$/u.test(data.name)) {
      reject(fields.name, text.invalidName);
    }

    if (!data.email) reject(fields.email, text.requiredEmail);
    else if (
      data.email.length > limits.email ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(data.email)
    ) {
      reject(fields.email, text.invalidEmail);
    }

    const cellDigits = data.cell.replace(/\D/g, "");
    if (!data.cell) reject(fields.cell, text.requiredCell);
    else if (
      data.cell.length > limits.cell ||
      !/^\+?[\d\s().-]+$/.test(data.cell) ||
      cellDigits.length < 10 ||
      cellDigits.length > 15
    ) {
      reject(fields.cell, text.invalidCell);
    }

    if (data.requestedInfo.length === 0) {
      reject(
        fields.info,
        text.requiredInfo,
        fields.info.querySelector('input[name="requested-info"]')
      );
    }

    if (fields.other.checked) {
      if (!data.otherDetails) reject(fields.otherDetails, text.requiredOther);
      else if (data.otherDetails.length > limits.otherDetails) {
        reject(fields.otherDetails, text.longOther);
      }
    }

    if (requestType === "message") {
      if (!data.message) reject(fields.message, text.requiredMessage);
      else if (data.message.length < 10) reject(fields.message, text.shortMessage);
      else if (data.message.length > limits.message) {
        reject(fields.message, text.longMessage);
      }
    }

    if (firstInvalid) {
      firstInvalid.focus();
      return { isValid: false, data: null };
    }

    fields.name.value = data.name;
    fields.email.value = data.email;
    fields.cell.value = data.cell;
    fields.otherDetails.value = data.otherDetails;
    fields.message.value = data.message;
    return { isValid: true, data };
  }

  function buildMessage(data) {
    const text = messages[getLanguage()];
    const labels = text.labels;
    const requestLabel =
      data.requestType === "message" ? labels.messageType : labels.infoType;
    const requestedInfo = data.requestedInfo
      .map((option) => text.infoOptions[option])
      .filter(Boolean)
      .join(", ");
    const lines = [
      `${labels.checkin}: ${data.checkin}`,
      `${labels.checkout}: ${data.checkout}`,
      `${labels.adults}: ${data.adults}`,
      `${labels.kids}: ${data.kids}`,
      `${labels.name}: ${data.name}`,
      `${labels.email}: ${data.email}`,
      `${labels.cell}: ${data.cell}`,
      `${labels.requestedInfo}: ${requestedInfo}`,
      `${labels.whatsappPreference}: ${data.whatsappPreference ? text.yes : text.no}`,
      `${labels.type}: ${requestLabel}`
    ];

    if (data.requestedInfo.includes("other")) {
      lines.push(`${labels.otherDetails}: ${data.otherDetails}`);
    }
    if (data.requestType === "message") {
      lines.push(`${labels.message}: ${data.message}`);
    }
    return lines.join("\n");
  }

  function buildSubject(data) {
    const text = messages[getLanguage()];
    const type =
      data.requestType === "message" ? text.messageSubject : text.infoSubject;
    return `${getLocalDate()} | ${type} - ${data.name}`;
  }

  function showStatus(message) {
    document.querySelector(".reserva-status-overlay")?.remove();
    const overlay = document.createElement("div");
    const modal = document.createElement("div");
    overlay.className = "reserva-status-overlay";
    overlay.setAttribute("role", "status");
    modal.className = "reserva-status-modal";
    modal.textContent = message;
    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    window.setTimeout(() => overlay.remove(), 1800);
  }

  function configureDateLimits(form) {
    if (!form) return;
    const checkin = form.querySelector("#br-checkin");
    const checkout = form.querySelector("#br-checkout");
    const today = getLocalDate();
    checkin.min = today;
    checkout.min = checkin.value || today;
  }

  function clearForm(form) {
    form.reset();
    form.querySelector(".message-field").hidden = true;
    form.querySelector(".other-details").hidden = true;
    form.querySelectorAll("[data-reserva-channel]").forEach((button) => {
      button.textContent = button.dataset.requestLabel;
    });
    form.querySelectorAll(".reserva-field-error").forEach((element) => element.remove());
    form.querySelectorAll('[aria-invalid="true"]').forEach((element) => {
      element.removeAttribute("aria-invalid");
    });
    configureDateLimits(form);
  }

  function openWhatsApp(data) {
    const url =
      `https://wa.me/${RESERVA_CONTACT.whatsapp}` +
      `?text=${encodeURIComponent(buildMessage(data))}`;
    showStatus(messages[getLanguage()].openingWhatsApp);
    window.open(url, "_blank", "noopener,noreferrer");
  }

  function openEmail(data) {
    const query = new URLSearchParams({
      cc: RESERVA_CONTACT.emailCc,
      subject: buildSubject(data),
      body: buildMessage(data)
    });
    const url = `mailto:${RESERVA_CONTACT.email}?${query.toString()}`;
    showStatus(messages[getLanguage()].openingEmail);
    window.open(url, "_blank", "noopener,noreferrer");
  }

  document.addEventListener("reserva:rendered", () => {
    configureDateLimits(getForm());
  });

  document.addEventListener("submit", (event) => {
    if (event.target.matches("#reserva-form")) event.preventDefault();
  });

  document.addEventListener("focusin", (event) => {
    if (!event.target.closest("#reserva-form")) return;
    clearFieldError(event.target);
    if (event.target.matches('input[name="requested-info"]')) {
      clearFieldError(event.target.closest(".info-options"));
    }
  });

  document.addEventListener("input", (event) => {
    if (!event.target.matches("#reserva-form #br-checkin")) return;
    const form = getForm();
    const checkout = form.querySelector("#br-checkout");
    checkout.min = event.target.value || getLocalDate();
  });

  document.addEventListener("change", (event) => {
    const option = event.target.closest('#reserva-form input[name="request-type"]');
    if (!option) return;
    const form = getForm();
    const useMessageLabels = option.value === "message";
    form.querySelectorAll("[data-reserva-channel]").forEach((button) => {
      button.textContent = useMessageLabels
        ? button.dataset.messageLabel
        : button.dataset.requestLabel;
    });
    if (!useMessageLabels) clearFieldError(form.querySelector("#br-msg"));
  });

  document.addEventListener("click", (event) => {
    const button = event.target.closest("#reserva-form [data-reserva-channel]");
    if (!button) return;
    const form = getForm();
    const result = validate(form);
    if (!result.isValid) return;

    if (button.dataset.reservaChannel === "whatsapp") {
      openWhatsApp(result.data);
    } else {
      openEmail(result.data);
    }
    clearForm(form);
  });
})();
